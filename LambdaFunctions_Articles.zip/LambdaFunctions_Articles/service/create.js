const AWS = require('aws-sdk');
AWS.config.update({
    region: 'us-east-1'
})
const util = require('../utils/util');

const dynamodb = new AWS.DynamoDB.DocumentClient();
const articleTable = 'articles';

async function create(createInfo) {
    const title = createInfo.title;
    const description = createInfo.description;
    const category = createInfo.category;
    const id = createInfo.id;
    const user_id = createInfo.user_id;
    
    if (!title || !description || !category || !id || !user_id) {
        return util.buildResponse(401, {
            message: 'All fields are required'
        })
    }

    const dynamoArticle = await getArticle(title);
    if (dynamoArticle && dynamoArticle.title) {
        return util.buildResponse(401, {
            message: 'title taken. Please choose a different title'
        })
    }

    const blogarticle = {
        title: title,
        description: description,
        category: category,
        id: id,
        user_id: user_id
    }

    const saveArticleResponse = await saveArticle(blogarticle);
    if (!saveArticleResponse) {
        return util.buildResponse(503, {message: 'Server Error. Please try again later.'});
    }

    return util.buildResponse(200, { title: title });
}

async function getArticle(id) {
    const params = {
        TableName: articleTable,
        Key: {
            id: id
        }
    }

    return await dynamodb.get(params).promise().then(response => {
        return response.Item;
    }, error => {
        console.error('There is an error: ', error);
    })
}

async function saveArticle(blogarticle) {
    const params = {
        TableName: articleTable,
        Item: blogarticle
    }
    return await dynamodb.put(params).promise().then(() => {
        return true;
    }, error => {
        console.error('There is an error saving arting:', error)
    });
}

module.exports.create = create;