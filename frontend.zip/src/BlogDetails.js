import { useParams } from 'react-router-dom';
import useFetch from './useFetch';
import BlogList from './service/BlogService';

const BlogDetails = () => {
    const { id } = useParams();
    const { data: blog, error, isPending } =  useFetch('https://7k32ty057b.execute-api.us-east-1.amazonaws.com/prod/blog' + id);

    return ( 
        <div className="blog-details">
            <div className="App">
                <BlogList/>
            </div>
            {isPending && <div>Loading...</div>}
            {error && <div>{error}</div>}
            <article >
                <h2>{blog.title}</h2>
                <p>Written by {blog.author}</p>
                <div>{blog.body}</div>
            </article>
        </div>
     );
}
 
export default BlogDetails;