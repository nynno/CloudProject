import React from "react";
import { TwitterShareButton, TwitterIcon, FacebookShareButton, FacebookIcon } from "react-share";

export default class FetchBlogDetails extends React.Component {
    state = {
        loading: true,
        article: [null]
    };

    async componentDidMount() {
        const url = "https://7k32ty057b.execute-api.us-east-1.amazonaws.com/prod/blogs";
        const requestConfig = {
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': 'iuFhGd5lhZ8kkQnFvYcvK8XTKfU1PLFY838jum2r'
            }
        }
        const response = await fetch(url, requestConfig);
        const data = await response.json();
        this.setState({article: data.blogs[1], loading: false})
    }

    render() {
        const currentURL = window.location.href
        return (
            <div className="blog-details">
                {this.state.loading || !this.state.article ? (
                    <div>loading...</div>
                ) : (
                    <div class="container">
                        <div class="share-btns">
                        <TwitterShareButton
                            url={`${currentURL}/blog/${this.state.article.id}`} 
                            title={this.state.article.title}>
                            <TwitterIcon logoFillColor="white" round={true}></TwitterIcon>
                        </TwitterShareButton>
                        <FacebookShareButton
                            url={`${currentURL}/blog/${this.state.article.id}`}
                            title={this.state.article.title}>
                            <FacebookIcon logoFillColor="white" round={true}></FacebookIcon>
                        </FacebookShareButton>
                        </div><br/>
                        <div class="post-title">{this.state.article.title}</div>
                        <hr class="thick dk"></hr>
                        <div class="post-category">Category: {this.state.article.category} |
                        Author: {this.state.article.user_id}</div> 
                        <div class="post-description">Description {this.state.article.description}</div>  
                    </div>
                )}
            </div>
        )
    }
}