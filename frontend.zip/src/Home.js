import React from 'react';
import { NavLink } from 'react-router-dom';

const Home = () => {

    const beerURL = "https://7k32ty057b.execute-api.us-east-1.amazonaws.com/prod/blogs";
    const requestConfig = {
        headers: {
            'Content-Type': 'application/json',
            'x-api-key': 'iuFhGd5lhZ8kkQnFvYcvK8XTKfU1PLFY838jum2r'
        }
    }

    fetch(beerURL, requestConfig,{mode: 'no-cors'})
    .then(function(response) {
        return response.text();
    })
    .then(function(text) {
        console.log('Request successful', text);
    })
    .catch(function(error) {
        console.log('Request failed', error)
    });

    return (
        <div>
            <div class="position-relative overflow-hidden p-3 p-md-5 m-md-3 text-center bg-light">
            <div class="col-md-10 p-lg-8 mx-auto my-5">
                <h1 class="display-4 font-weight-normal">Welcome to the Covex App</h1>
                <p class="lead font-weight-normal">
                    Covex App is a platform whereby you can read about people's experience that have had Covid 19.
                </p>
                <NavLink activeClassName="active" to="/create">Share Experience Today</NavLink>
            </div>
            <div class="product-device box-shadow d-none d-md-block"></div>
            <div class="product-device product-device-2 box-shadow d-none d-md-block"></div>
            </div>
        </div>
    )

}

export default Home;