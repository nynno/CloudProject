import { useEffect, useState } from 'react';
import axios from 'axios';

export default function Parent() {
    // get data from API
    const [blogs, getBlogs] = useState('');

    const url = "https://7k32ty057b.execute-api.us-east-1.amazonaws.com/prod/blogs";

    useEffect(() => {
        getAllBlogs();
    }, []);

    const getAllBlogs = () => {
        axios.get(`${url}past`)
        .then((response) => {
            const allBlogs = response.data.blogs.allBlogs;
            getBlogs(allBlogs);
        }).catch(error => console.error(`Error: ${error}`));
    }
    return (
        blogs
    )

}