import React from "react";
import { Link } from "react-router-dom";

export default class FetchArticles extends React.Component {
    state = {
        loading: true,
        article: [null],
        article2: [null],
        article3: [null],
        article4: [null],
        article5: [null]
    };

    async componentDidMount() {
        const url = "https://7k32ty057b.execute-api.us-east-1.amazonaws.com/prod/blogs";
        const requestConfig = {
            headers: {
                'Content-Type': 'application/json',
                'x-api-key': 'iuFhGd5lhZ8kkQnFvYcvK8XTKfU1PLFY838jum2r'
            }
        }
        const response = await fetch(url, requestConfig);
        const data = await response.json();
        this.setState({article: data.blogs[1], loading: false})
        this.setState({article2: data.blogs[2], loading: false})
        this.setState({article3: data.blogs[3], loading: false})
        this.setState({article4: data.blogs[4], loading: false})
        this.setState({article5: data.blogs[5], loading: false})
    }

    render() {
        return (
            <div>
                {this.state.loading && this.state.article2 && this.state.article3 && this.state.article4 && this.state.article5 || !this.state.article ? (
                    <div>loading...</div>
                ) : (
                    <div>
                        <h1 class="home-title">Recent Covid Posts</h1>
                        <div class="card">
                            <div class="card-body">
                            <Link to={`/blog/${this.state.article.id}`}>
                                <h5 class="card-title">{this.state.article.title}</h5>
                            </Link>
                                <p class="card-text">Category: {this.state.article.category}</p>
                                <div class="author">Author: {this.state.article.user_id}</div>
                            </div>
                        </div><br/>

                        <div class="card">
                            <div class="card-body">
                            <Link to={`/blog/${this.state.article2.id}`}>
                                <h5 class="card-title">{this.state.article2.title}</h5>
                            </Link>
                                <p class="card-text">Category: {this.state.article2.category}</p>
                                <div class="author">Author: {this.state.article2.user_id}</div>
                            </div>
                        </div><br/>

                        <div class="card">
                            <div class="card-body">
                            <Link to={`/blog/${this.state.article3.id}`}>
                                <h5 class="card-title">{this.state.article3.title}</h5>
                            </Link>
                                <p class="card-text">Category: {this.state.article3.category}</p>
                                <div class="author">Author: {this.state.article3.user_id}</div>
                            </div>
                        </div><br/>

                        <div class="card">
                            <div class="card-body">
                            <Link to={`/blog/${this.state.article4.id}`}>
                                <h5 class="card-title">{this.state.article4.title}</h5>
                            </Link>
                                <p class="card-text">Category: {this.state.article4.category}</p>
                                <div class="author">Author: {this.state.article4.user_id}</div>
                            </div>
                        </div><br/>

                        <div class="card">
                            <div class="card-body">
                            <Link to={`/blog/${this.state.article5.id}`}>
                                <h5 class="card-title">{this.state.article5.title}</h5>
                            </Link>
                                <p class="card-text">Category: {this.state.article5.category}</p>
                                <div class="author">Author: {this.state.article5.user_id}</div>
                            </div>
                        </div><br/>

                </div>
                )}
            </div>
        )
    }
}