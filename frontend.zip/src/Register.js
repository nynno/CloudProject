import React, {useState} from 'react';
import axios from 'axios';
import { NavLink } from 'react-router-dom';

const registerUrl = 'https://ubmdpvtgae.execute-api.us-east-1.amazonaws.com/prod/register';

const Register = () => {
    const [name, setName] = useState('');
    const [email, setEmail] = useState('');
    const [username, setUsername] = useState('');
    const [password, setpassword] = useState('');
    const [message, setMessage] = useState(null);

    const submitHandler = (event) => {
        event.preventDefault();
        if (username.trim() === '' || email.trim === ''|| name.trim() === '' || password.trim() === '') {
            setMessage('All fields are required');
            return
        }
        setMessage(null);
        const requestConfig = {
            headers: {
                'x-api-key': 'iuFhGd5lhZ8kkQnFvYcvK8XTKfU1PLFY838jum2r'
            }
        }

        const requestBody = {
            username: username,
            email: email,
            name: name,
            password: password
        }
        axios.post(registerUrl, requestBody, requestConfig).then(response => {
            setMessage('Registration Successful');
        }).catch(error => {
            if(error.response.status === 401 || error.response.status === 403) {
                setMessage(error.response.data.message);
            } else {
                setMessage('sorry... the server is down!! please try again later');
            }
        })
    }

    return (
        <div>

<div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
    <div class="card card0 border-0">
        <div class="row d-flex">
        <form onSubmit={submitHandler}>
            <div class="col-lg-6">
            <h2 class="text-center text-dark mt-5">Welcome to Covex App</h2>
                <div class="text-center mb-5 text-dark">Register New Account</div>
                <div class="card2 card border-0 px-4 py-5">
                    <div class="row px-3"> 
                        <label class="mb-1">
                            <h6 class="mb-0 text-sm">Name</h6>
                        </label> 
                        <input class="mb-4" type="text" name="name" placeholder="Please Enter Your Name"
                        value={name} onChange={event => setName(event.target.value)}/> 
                    </div>
                    <div class="row px-3"> 
                        <label class="mb-1">
                            <h6 class="mb-0 text-sm">Email Address</h6>
                        </label> 
                        <input class="mb-4" type="text" name="email" placeholder="Enter a valid email address"
                        value={email} onChange={event => setEmail(event.target.value)}/> 
                    </div>
                    <div class="row px-3"> 
                        <label class="mb-1">
                            <h6 class="mb-0 text-sm">Username</h6>
                        </label> 
                        <input class="mb-4" type="text" name="username" placeholder="Choose Username"
                        value={username} onChange={event => setUsername(event.target.value)}/> 
                    </div>
                    <div class="row px-3"> 
                        <label class="mb-1">
                            <h6 class="mb-0 text-sm">Password</h6>
                        </label> 
                        <input type="password" name="password" placeholder="Enter password"
                        value={password} onChange={event => setpassword(event.target.value)}/> 
                    </div><br/>
                    <div class="row px-3"> 
                        <input type="submit" value="Register" />
                    </div><br/>
                    <div class="row mb-4 px-3"> 
                        <small class="font-weight-bold">Have an account? 
                            <NavLink class="text-dark fw-bold" activeClassName="active" to="/login">Login</NavLink>
                        </small> 
                    </div>
                </div>
            </div>
        </form>
        {message && <p className="message">{message}</p>}
        </div>
        <div class="bg-blue py-4">
            <div class="row px-3"> <small class="ml-4 ml-sm-5 mb-2">Copyright &copy; 2019. All rights reserved.</small>
                <div class="social-contact ml-4 ml-sm-auto"> <span class="fa fa-facebook mr-4 text-sm"></span> <span class="fa fa-google-plus mr-4 text-sm"></span> <span class="fa fa-linkedin mr-4 text-sm"></span> <span class="fa fa-twitter mr-4 mr-sm-5 text-sm"></span> </div>
            </div>
        </div>
    </div>
</div>

        </div>
    )
}

export default Register;