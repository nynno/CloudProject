import {NavLink } from 'react-router-dom';

const Navbar = () => {
    return ( 
        <nav className="navbar">
            <a class="linky" href="/" to="/">
            <img src="https://mydogsinfo.com/wp-content/uploads/2022/04/covex.png" 
            class="img-fluid profile-image-pic img-thumbnail my-3"
                max-width="200px" height="30px" alt="profile"/>
            </a>
            <div className="links">
                <NavLink exact activeClassName="active" to="/">Home</NavLink>
                <NavLink activeClassName="active" to="/create">Create Blog</NavLink>
                <NavLink activeClassName="active" to="/blogs">Blogs</NavLink>
                <NavLink activeClassName="active" to="/register">Register</NavLink>
                <NavLink activeClassName="active" to="/login">Login</NavLink>
                  
            </div>
        </nav>
     );
}
 
export default Navbar;