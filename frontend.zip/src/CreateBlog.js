import axios from 'axios';
import React, {useState} from 'react';
import { getUser, resetUserSession } from './service/AuthService';

const createUrl = 'https://7k32ty057b.execute-api.us-east-1.amazonaws.com/prod/blog';

const Create = (props) => {
    const user = getUser();
    const username = user !== 'undefined' && user ? user.username : '';
    const name = user !== 'undefined' && user ? user.name : '';

    const logoutHandler = () => {
        resetUserSession();
        props.history.push('login');
    }

    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [category, setCategory] = useState('');
    const [id] = useState(() => `${Math.random().toString(16).slice(2)}`);
    const [user_id] = useState(username);
    const [message, setMessage] = useState(null);
    
    const submitHandler = (event) => {
        event.preventDefault();
        if (title.trim() === '' || description.trim() === '' || category.trim() === '' || id.trim() === '' ) {
            setMessage('All fields are required');
            return
        }  
        setMessage(null);
        const requestConfig = {
            headers: {
                'x-api-key': 'iuFhGd5lhZ8kkQnFvYcvK8XTKfU1PLFY838jum2r'
            }
        }
        const requestBody = {
            title: title,
            description: description,
            category: category,
            id: id,
            user_id: user_id
        }
    
        axios.post(createUrl, requestBody, requestConfig).then(response => {
            setMessage('Post Added Successfully');
        }).catch(error => {
            if(error.response.status === 401 || error.response.status === 403) {
                setMessage(error.response.data.message);
            } else {
                setMessage('sorry... the server is down!! please try again later');
            }
        })

    }
    
    return (
    <div class="container-fluid px-1 px-md-5 px-lg-1 px-xl-5 py-5 mx-auto">
        <div class="loggedd">
            Hello {name}! You are logged in!!! Welcome. <br/>
            <input type="button" class="logged-btn" value="Logout" onClick={logoutHandler} />
        </div>
        <h2 class="title-top">Add A New Blog</h2>
        <div class="card card0 border-0">
            <div class="row d-flex"></div>
            
            <div className="create">
                <form onSubmit={submitHandler}>
                <label>Blog Title</label>
                    <input 
                        type="text"
                        value={title}
                        onChange={event => setTitle(event.target.value)}
                    />
                <label>Blog Body</label>
                    <textarea
                        value={description}
                        onChange={event => setDescription(event.target.value)}
                    />
                <label>Blog Category:</label>
                    <select class="custom-select" id="inputGroupSelect01"
                        value={category}
                        onChange={event => setCategory(event.target.value)}
                    >
                        <option value="">Choose Category</option>
                        <option value="Fashion">Fashion</option>
                        <option value="Lifestyle">Lifestyle</option>
                        <option value="Food">Food</option>
                        <option value="Travel">Travel</option>
                    </select>

                    <input type="submit" class="btn btn-success" value="Create" />
                </form>
                {message && <p className="message">{message}</p>}
            </div>
        </div>
    </div>
    )
}

export default Create;