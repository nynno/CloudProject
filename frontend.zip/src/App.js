import { BrowserRouter, Route, Switch} from "react-router-dom";
import Home from "./Home";
import Login from "./Login";
import PremiumContent from "./PremiumContent";
import Register from "./Register";
import PublicRoute from "./routes/PublicRoute";
import PrivateRoute from "./routes/PrivateRoute";
import React, { useState, useEffect } from "react";
import { getUser, getToken, setUserSession, resetUserSession } from "./service/AuthService";
import axios from "axios";
import 'bootstrap/dist/css/bootstrap.min.css';

import Navbar from './Navbar';
import Create from './CreateBlog';
import BlogDetails from './BlogDetails';
import NotFound from './NotFound';
import api from './api/blogs';

const verifyTokenAPIURL = 'https://ubmdpvtgae.execute-api.us-east-1.amazonaws.com/prod/verify';

function App() {
  const [BlogDetails, setBlogs] = useState([]);

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const response = await api.get('/blogs');
        setBlogs(response.data);
      } catch (err) {
        if (err.response) {
          // Not in the 200 response range 
          console.log(err.response.data);
          console.log(err.response.status);
          console.log(err.response.headers);
        } else {
          console.log(`Error: ${err.message}`);
        }
      }
    }

    fetchBlogs();
  }, [])


  const [isAuthenicating, setAuthenicating] = useState(true);

  useEffect(() => {
    const token = getToken();
    if (token === 'undefined' || token === undefined || token === null || !token) {
      return;
    }

    const requestConfig = {
      headers: {
          'x-api-key': 'iuFhGd5lhZ8kkQnFvYcvK8XTKfU1PLFY838jum2r'
      }
    }
    const requestBody = {
      user: getUser(),
      token: token
    }

    axios.post(verifyTokenAPIURL, requestBody, requestConfig).then(response => {
      setUserSession(response.data.user, response.data.token);
      setAuthenicating(false);
    }).catch(() => {
      resetUserSession();
      setAuthenicating(false);
    })
  }, []);

  const token = getToken();
  if (isAuthenicating && token) {
    return <div className="content">Authenticating...</div>
  }

  return (

    <div className="App">
      
      <BrowserRouter>
      <div className="header"> 
        <Navbar/>
      </div>
      <div className="content">
        <Switch>
          <Route exact path="/" component={Home}/>
          <PublicRoute path="/register" component={Register}/>
          <PublicRoute path="/login" component={Login}/>
          <PrivateRoute path="/premium-content" component={PremiumContent}/>

          <PrivateRoute path="/create" component={Create}/>
          <Route path="/blog" component={BlogDetails}/>
          <Route path="*" component={NotFound}/>
  
        </Switch>
      </div>
      </BrowserRouter>
    </div>
  );
}

export default App;


