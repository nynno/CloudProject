import React from 'react';
import { getUser, resetUserSession } from './service/AuthService';

const LogNav = (props) => {
    const user = getUser();
    const name = user !== 'undefined' && user ? user.name : '';

    const logoutHandler = () => {
        resetUserSession();
        props.history.push('login');
    }
    return (
        <div>
            <div className=''>Welcome {name}</div>
            <input type="button" value="Logout" onClick={logoutHandler} />
        </div>
    )
}

export default LogNav;