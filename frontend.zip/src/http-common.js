import axios from "axios";
export default axios.create({
  baseURL: "https://7k32ty057b.execute-api.us-east-1.amazonaws.com/prod",
  headers: {
    'Access-Control-Allow-Origin': '*',
    'Content-Type': 'application/json'
  }
});