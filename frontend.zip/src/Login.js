import axios from 'axios';
import React, { useState } from 'react';
import { setUserSession } from './service/AuthService';
import { NavLink } from 'react-router-dom';

const loginUrl = 'https://ubmdpvtgae.execute-api.us-east-1.amazonaws.com/prod/login';

const Login = (props) => {
    const [username, setUsername] = useState('');
    const [password, setPassword] = useState('');
    const [errorMessage, setErrorMessage] = useState(null);

    const submitHandler = (event) => {
        event.preventDefault();
        if(username.trim() === '' || password.trim() === '') {
            setErrorMessage('Both username and password are required');
            return;
        }
        setErrorMessage(null);
        const requestConfig = {
            headers: {
                'x-api-key': 'iuFhGd5lhZ8kkQnFvYcvK8XTKfU1PLFY838jum2r'
            }
        }
        const requestBody = {
            username: username,
            password: password
        }

        axios.post(loginUrl, requestBody, requestConfig).then((response) => {
            setUserSession(response.data.user, response.data.token);
            props.history.push('/create');
        }).catch((error) => {
            if(error.response.status === 401 || error.response.status === 403) {
                setErrorMessage(error.response.data.message);
            } else {
                setErrorMessage('sorry... the server is down!! please try again later');
            }
        })
    }

    return (
        
<div>
    <div class="container">
    <div class="row">
      <div class="col-md-6 offset-md-3">
        <h2 class="text-center text-dark mt-5">Login Form</h2>
        <div class="text-center mb-5 text-dark">Welcome to Covex App</div>
        <div class="card my-5">

          <form onSubmit={submitHandler} class="card-body cardbody-color p-lg-5">

            <div class="text-center">
              <img src="https://cdn.pixabay.com/photo/2016/03/31/19/56/avatar-1295397__340.png" class="img-fluid profile-image-pic img-thumbnail rounded-circle my-3"
                width="200px" alt="profile"/>
            </div>

            <div class="mb-3">
              <input type="text" class="form-control" id="Username" aria-describedby="emailHelp"
                placeholder="User Name" value={username} onChange={event => setUsername(event.target.value)}/>
            </div>
            <div class="mb-3">
              <input type="password" class="form-control" id="password" placeholder="password"
              value={password} onChange={event => setPassword(event.target.value)}/>
            </div>
            <div class="text-center">
                <input type="submit" class="btn btn-color px-5 mb-5 w-100" value="Login" />
            </div>
            <div id="emailHelp" class="form-text text-center mb-5 text-dark">Not
              Registered? <NavLink class="text-dark fw-bold" activeClassName="active" to="/register">Create an
                Account</NavLink>
              
            </div>
          </form>
          {errorMessage && <p className='message'>{errorMessage}</p>}
        </div>

      </div>
    </div>
  </div>
            
</div>
    )
}

export default Login;